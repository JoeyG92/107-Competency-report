
const Navbar = () => {
    return (
        <div>
            <h1>I'm a Navbar</h1>
        </div>
    );
}

export default Navbar;