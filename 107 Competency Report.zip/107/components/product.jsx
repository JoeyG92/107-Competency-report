

import "./product.css";

const Product = () => {
    return (
        <div className="product">
            <h3>I'm a product</h3>
        </div>
    );
};

export default Product;
